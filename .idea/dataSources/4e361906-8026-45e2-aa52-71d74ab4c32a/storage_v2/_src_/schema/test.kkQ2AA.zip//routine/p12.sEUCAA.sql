create procedure p12()
  begin
    declare row_id int;
    declare row_name varchar(20);
    declare row_num int;
    declare you int default 1;
    declare getdoods cursor for select id,goodsName,num from goods;
    declare continue handler for NOT FOUND set you=0;
        open getdoods;
       while you=1 do
    fetch getdoods into row_id,row_name,row_num;
      select row_name,row_num;
    end while;
    close getdoods;
    end;

