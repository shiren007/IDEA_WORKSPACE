create procedure p6(IN n INT(10))
  begin
declare num int default 0;
 declare total int default 0;
while num <=n do
set total = total+num;
set num = num+1;
end while;
select total;
end;

