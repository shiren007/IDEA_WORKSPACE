create procedure p1(IN width INT(10), IN height INT(10))
  begin 
if width > height
then select 'fat' as shencai;
else select 'shou' as shencai;
end if;
select concat('square is',width * height) as area;
end;

