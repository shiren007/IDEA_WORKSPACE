create procedure p11()
  begin
    declare row_id int;
    declare row_name varchar(20);
    declare row_num int;
    declare count int;
    declare start int default 0;
    declare getdoods cursor for select id,goodsName,num from goods;
    select count(*) from goods into count;
        open getdoods;
       while start<count do
      set start=start+1;
    fetch getdoods into row_id,row_name,row_num;
      select row_name,row_num;
    end while;
    close getdoods;
    end;

