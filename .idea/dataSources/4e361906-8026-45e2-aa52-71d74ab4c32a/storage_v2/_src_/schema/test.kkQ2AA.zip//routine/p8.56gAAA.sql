create procedure p8()
  begin
declare total int default 0;
declare num int default 0;
repeat
set num=num+1;
set total = total + num;
until num >= 100 end repeat;
select total
;
end;

