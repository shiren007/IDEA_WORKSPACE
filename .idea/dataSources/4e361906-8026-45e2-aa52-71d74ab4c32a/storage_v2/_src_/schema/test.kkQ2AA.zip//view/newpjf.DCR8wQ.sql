create view newpjf as /* ALGORITHM=UNDEFINED */
  select
    `test`.`result`.`cat_id`     AS `cat_id`,
    avg(`test`.`result`.`score`) AS `pj`
  from `test`.`result`
  group by `test`.`result`.`cat_id`;

