create view pjf as /* ALGORITHM=UNDEFINED */
  select
    `test`.`result`.`cat_id`     AS `cat_id`,
    avg(`test`.`result`.`score`) AS `avg(score)`
  from `test`.`result`
  group by `test`.`result`.`cat_id`;

