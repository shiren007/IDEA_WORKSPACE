create procedure p9()
  begin
declare row_id int;
declare row_name varchar(20);
declare row_num int;
declare getgoods cursor for select id,goodsName,num from goods;
open getgoods;
fetch getgoods into row_id,row_name,row_num;
select row_name,row_num;
close getgoods;
end;

